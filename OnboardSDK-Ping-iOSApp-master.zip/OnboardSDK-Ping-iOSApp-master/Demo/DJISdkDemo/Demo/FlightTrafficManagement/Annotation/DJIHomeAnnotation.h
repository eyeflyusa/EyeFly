//
//  DJIHomeAnnotation.h
//
//
//  Copyright (c) 2015 DJI All rights reserved.
//

#import "DJIAnnotation.h"
@interface DJIHomeAnnotation : DJIAnnotation

@end
