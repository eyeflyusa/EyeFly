#ifndef DJI_MEMORY_H
#define DJI_MEMORY_H

#include "DJI_Type.h"

#endif // DJI_MEMORY_H
