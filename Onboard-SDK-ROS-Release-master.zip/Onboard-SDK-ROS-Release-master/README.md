## dji_onboardsdk_ros (indigo) - 0.1.9-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Tue, 14 Jun 2016 10:28:05 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.8-0`
- old version: `0.1.8-0`
- new version: `0.1.9-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.8-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Sun, 12 Jun 2016 11:18:46 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.7-0`
- old version: `0.1.7-0`
- new version: `0.1.8-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.7-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Thu, 21 Apr 2016 07:24:13 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.6-0`
- old version: `0.1.6-0`
- new version: `0.1.7-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.6-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Wed, 13 Apr 2016 08:14:59 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.5-0`
- old version: `0.1.5-0`
- new version: `0.1.6-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.5-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Thu, 07 Apr 2016 06:35:28 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.4-0`
- old version: `0.1.4-0`
- new version: `0.1.5-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.4-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Sun, 03 Apr 2016 14:58:34 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.3-0`
- old version: `0.1.3-0`
- new version: `0.1.4-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.3-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Wed, 30 Mar 2016 11:35:53 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.2-0`
- old version: `0.1.2-0`
- new version: `0.1.3-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.2-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Wed, 30 Mar 2016 06:07:21 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.1-0`
- old version: `0.1.1-0`
- new version: `0.1.2-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.10`
- rosdep version: `0.11.4`
- rosdistro version: `0.4.5`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.1-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release dji_onboardsdk_ros --track indigo --rosdistro indigo` on `Tue, 29 Mar 2016 08:31:44 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: https://github.com/dji-sdk/Onboard-SDK-ROS-Release.git
- rosdistro version: `0.1.0-0`
- old version: `0.1.0-0`
- new version: `0.1.1-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.8`
- rosdep version: `0.11.2`
- rosdistro version: `0.4.2`
- vcstools version: `0.1.38`


## dji_onboardsdk_ros (indigo) - 0.1.0-0

The packages in the `dji_onboardsdk_ros` repository were released into the `indigo` distro by running `/usr/bin/bloom-release --rosdistro indigo --track indigo dji_onboardsdk_ros --edit` on `Fri, 25 Mar 2016 14:22:14 -0000`

These packages were released:
- `dji_sdk`
- `dji_sdk_demo`
- `dji_sdk_dji2mav`
- `dji_sdk_lib`
- `dji_sdk_web_groundstation`

Version of package(s) in repository `dji_onboardsdk_ros`:

- upstream repository: https://github.com/dji-sdk/Onboard-SDK-ROS.git
- release repository: unknown
- rosdistro version: `null`
- old version: `null`
- new version: `0.1.0-0`

Versions of tools used:

- bloom version: `0.5.21`
- catkin_pkg version: `0.2.8`
- rosdep version: `0.11.2`
- rosdistro version: `0.4.2`
- vcstools version: `0.1.38`


# Onboard-SDK-ROS-Release