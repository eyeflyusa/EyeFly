//
//  MOSMainTabViewController.h
//  MOS
//
//
//  Copyright © 2016 DJI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface MOSMainTabViewController : UITabBarController

@property (weak, nonatomic) AppDelegate *appDelegate;

@end
