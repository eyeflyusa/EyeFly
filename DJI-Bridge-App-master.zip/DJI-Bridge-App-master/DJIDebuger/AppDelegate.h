//
//  AppDelegate.h
//  DJIDebuger
//
//  Created by DJI on 15/10/13.
//  Copyright © 2015年 DJI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

