//
//  main.m
//  DJIDebuger
//
//  Created by DJI on 15/10/13.
//  Copyright © 2015年 DJI. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
