## DJI SDK DJI2MAV 

Documentation has been moved to the developer website. 

First time users of OnboardSDK, please refer to the below link:
https://developer.dji.com/onboard-sdk/documentation/quick-start/index.html

ROS Mav package documentation:
https://developer.dji.com/onboard-sdk/documentation/github-platform-docs/ROS_Example/ros_dji2mav_0.2.1_package.html