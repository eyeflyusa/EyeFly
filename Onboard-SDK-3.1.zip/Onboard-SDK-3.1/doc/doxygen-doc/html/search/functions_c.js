var searchData=
[
  ['updatetarget',['updateTarget',['../classDJI_1_1onboardSDK_1_1Follow.html#af8f6a63b95c36febe8164e2002fd813d',1,'DJI::onboardSDK::Follow']]],
  ['uploadindexdata',['uploadIndexData',['../classDJI_1_1onboardSDK_1_1WayPoint.html#ae2f37131569b4e0ee50e6ff0e69af86b',1,'DJI::onboardSDK::WayPoint::uploadIndexData(WayPointData *data, CallBack callback=0, UserData userData=0)'],['../classDJI_1_1onboardSDK_1_1WayPoint.html#a6a49aa300981094c6be97b0d198ae876',1,'DJI::onboardSDK::WayPoint::uploadIndexData(uint8_t pos, CallBack callback=0, UserData userData=0)']]]
];
